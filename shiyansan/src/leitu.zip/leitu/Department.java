//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Department.java

package leitu;


public class Department 
{
   
   /**
    * @roseuid 653F39410179
    */
   public Department() 
   {
    
   }
}
