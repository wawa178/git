//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Credit.java

package leitu;


public class Credit 
{
   private int number;
   private int type;
   private int expireDate;
   public Payment thePayment;
   
   /**
    * @roseuid 653F3A0603B7
    */
   public Credit() 
   {
    
   }
}
