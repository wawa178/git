//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Product.java

package leitu;


public class Product 
{
   private int title;
   private int weight;
   private int description;
   public Customer theCustomer;
   
   /**
    * @roseuid 653F3A07025D
    */
   public Product() 
   {
    
   }
   
   /**
    * @roseuid 652E13980279
    */
   public void getPriceForQuantity() 
   {
    
   }
   
   /**
    * @roseuid 652E139B0348
    */
   public void getWeight() 
   {
    
   }
}
