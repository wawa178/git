//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Customer.java

package leitu;


public class Customer 
{
   private int name;
   private int contact;
   private int deliveryAddress;
   private int active;
   
   /**
    * @roseuid 653F3A070299
    */
   public Customer() 
   {
    
   }
}
