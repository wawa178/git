//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\DELIVERED.java

package leitu;


public class DELIVERED 
{
   public Order theOrder;
   
   /**
    * @roseuid 653F3A07017E
    */
   public DELIVERED() 
   {
    
   }
}
