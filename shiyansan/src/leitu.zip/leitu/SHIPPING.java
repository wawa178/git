//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\SHIPPING.java

package leitu;


public class SHIPPING 
{
   public Order theOrder;
   
   /**
    * @roseuid 653F3A070129
    */
   public SHIPPING() 
   {
    
   }
}
