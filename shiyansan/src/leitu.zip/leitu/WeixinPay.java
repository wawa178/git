//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\WeixinPay.java

package leitu;


public class WeixinPay 
{
   private int cardnumber;
   public Payment thePayment;
   
   /**
    * @roseuid 653F3A0700AB
    */
   public WeixinPay() 
   {
    
   }
}
