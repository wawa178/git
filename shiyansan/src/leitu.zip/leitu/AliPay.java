//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\AliPay.java

package leitu;


public class AliPay 
{
   private int number;
   public Payment thePayment;
   
   /**
    * @roseuid 653F3A070048
    */
   public AliPay() 
   {
    
   }
}
