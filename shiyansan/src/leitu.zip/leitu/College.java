//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\College.java

package leitu;


public class College 
{
   
   /**
    * @roseuid 653F393302D8
    */
   public College() 
   {
    
   }
}
