//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Order.java

package leitu;


public class Order 
{
   private int CreatDate;
   private int status;
   
   /**
    * @roseuid 653F3A07021C
    */
   public Order() 
   {
    
   }
}
