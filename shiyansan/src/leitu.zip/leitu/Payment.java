//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Payment.java

package leitu;


public class Payment 
{
   private int amount;
   public Customer theCustomer;
   
   /**
    * @roseuid 653F3A0702E2
    */
   public Payment() 
   {
    
   }
}
