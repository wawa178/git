//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\School.java

package leitu;


public class School 
{
   
   /**
    * @roseuid 653F394101AE
    */
   public School() 
   {
    
   }
}
