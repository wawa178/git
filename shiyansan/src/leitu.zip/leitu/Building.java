//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Building.java

package leitu;


public class Building 
{
   
   /**
    * @roseuid 653F393302FC
    */
   public Building() 
   {
    
   }
}
