//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Course.java

package leitu;


public class Course 
{
   public Student theStudent;
   
   /**
    * @roseuid 653F3933031F
    */
   public Course() 
   {
    
   }
}
