//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Subject.java

package leitu;


public class Subject 
{
   
   /**
    * @roseuid 653F394101D4
    */
   public Subject() 
   {
    
   }
}
