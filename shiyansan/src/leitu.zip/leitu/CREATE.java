//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\CREATE.java

package leitu;


public class CREATE 
{
   public Order theOrder;
   
   /**
    * @roseuid 653F3A070101
    */
   public CREATE() 
   {
    
   }
}
