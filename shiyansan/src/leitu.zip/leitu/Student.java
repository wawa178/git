//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Student.java

package leitu;


public class Student 
{
   
   /**
    * @roseuid 653F39410201
    */
   public Student() 
   {
    
   }
}
