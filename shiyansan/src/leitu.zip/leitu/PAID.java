//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\PAID.java

package leitu;


public class PAID 
{
   public Order theOrder;
   
   /**
    * @roseuid 653F3A0700EB
    */
   public PAID() 
   {
    
   }
}
