//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\OrderDetail.java

package leitu;


public class OrderDetail 
{
   private int quantity;
   
   /**
    * @roseuid 653F3A0701E8
    */
   public OrderDetail() 
   {
    
   }
   
   /**
    * @roseuid 652E132A022E
    */
   public void calculateSubTotal() 
   {
    
   }
   
   /**
    * @roseuid 652E132C035B
    */
   public void calculateWeight() 
   {
    
   }
}
