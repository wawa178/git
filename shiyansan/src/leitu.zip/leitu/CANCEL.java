//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\CANCEL.java

package leitu;


public class CANCEL 
{
   public Order theOrder;
   
   /**
    * @roseuid 653F3A070155
    */
   public CANCEL() 
   {
    
   }
}
