//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\WireTransfer.java

package leitu;


public class WireTransfer 
{
   private int bankID;
   private int bankname;
   public Payment thePayment;
   
   /**
    * @roseuid 653F3A070013
    */
   public WireTransfer() 
   {
    
   }
}
