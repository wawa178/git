//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\status.java

package leitu;


public class status 
{
   public Order theOrder;
   
   /**
    * @roseuid 653F3A0701B7
    */
   public status() 
   {
    
   }
}
