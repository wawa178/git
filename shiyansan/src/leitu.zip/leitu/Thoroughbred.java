//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Thoroughbred.java

package leitu;


public class Thoroughbred 
{
   private Thoroughbred father;
   private Thoroughbred mother;
   private int birthyear;
   
   /**
    * @roseuid 653F360F0112
    */
   public Thoroughbred() 
   {
    
   }
   public class Date{

   }

   /**
    * @return leitu.Thoroughbred
    * @roseuid 652DFFC50292
    */
   public Thoroughbred getFather() 
   {
    return null;
   }
   
   /**
    * @return leitu.Thoroughbred
    * @roseuid 652DFFE100BE
    */
   public Thoroughbred getMother() 
   {
    return null;
   }
   
   /**
    * @param currentYear
    * @return int
    * @roseuid 652DFFE2014A
    */
   public int getCurrentAge(Date currentYear) 
   {
    return 0;
   }
}
