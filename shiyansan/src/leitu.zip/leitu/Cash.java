//Source file: E:\\BaiduNetdiskDownload\\web\\exercise\\shiyansan\\src\\leitu\\Cash.java

package leitu;


public class Cash 
{
   private int cashTendered;
   public Payment thePayment;
   
   /**
    * @roseuid 653F3A07007B
    */
   public Cash() 
   {
    
   }
}
